import pandas as pd
import os

file_path = r"../data_raw/student_performance.csv"


if not os.path.exists(file_path):
    print(f"Error: File not found at {os.path.abspath(file_path)}")
else:
    # Load dataset
    df = pd.read_csv(file_path)

    # Filled missing values with column mean
    df.fillna(df.mean(), inplace=True)

    # Save cleaned data
    output_path = r"../data_clean/clean_student_performance.csv"
    df.to_csv(output_path, index=False)

    print(f"Data cleaning complete. Saved as {output_path}")

