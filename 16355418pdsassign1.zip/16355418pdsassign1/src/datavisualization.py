import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Ensure the results directory exists
results_dir = "../results"
os.makedirs(results_dir, exist_ok=True)

# Load dataset
file_path = "C:\Documents/16355418pdsassign1/data_clean/clean_students_performance.csv"

if not os.path.exists(file_path):
    print(f"Error: File not found at {file_path}")
else:
    df = pd.read_csv(file_path)

    # Creating a new column for the average score
    df['average_score'] = df[['math score', 'reading score', 'writing score']].mean(axis=1)

    # 1. Horizontal Bar Chart: Average Score by Parental Education
    plt.figure(figsize=(10, 6))
    df.groupby("parental level of education")["average_score"].mean().sort_values().plot(kind="barh", color="skyblue")
    plt.xlabel("Average Score")
    plt.ylabel("Parental Education Level")
    plt.title("Average Score by Parental Education (Horizontal Bar Chart)")
    plt.savefig(os.path.join(results_dir, "horizontal_bar_parental_education.png"))  
    plt.close()

    
    # 2. Line Graph: Trend of Scores Across Subjects
    plt.figure(figsize=(10, 6))
    df[['math score', 'reading score', 'writing score']].mean().plot(kind="line", marker="o", linestyle="--", color="b")
    plt.ylabel("Average Score")
    plt.xlabel("Subjects")
    plt.title("Trend of Average Scores Across Subjects (Line Graph)")
    plt.grid(True)
    plt.savefig(os.path.join(results_dir, "line_graph_scores.png"))  
    plt.close()

    #3. Pie Chart: Gender Distribution
    plt.figure(figsize=(6, 6))
    df["gender"].value_counts().plot(kind="pie", autopct="%1.1f%%", colors=["pink", "lightblue"])
    plt.title("Gender Distribution (Pie Chart)")
    plt.ylabel("")  
    plt.savefig(os.path.join(results_dir, "pie_chart_gender.png"))  
    plt.close()

    # 4. Scatter Plot: Relationship Between Study Hours and Math Scores
    if "study hours" in df.columns:  
        plt.figure(figsize=(8, 6))
        sns.scatterplot(x=df["study hours"], y=df["math score"], color="red", alpha=0.6)
        plt.xlabel("Study Hours")
        plt.ylabel("Math Score")
        plt.title("Study Hours vs. Math Score (Scatter Plot)")
        plt.savefig(os.path.join(results_dir, "scatter_study_hours_math.png"))  
        plt.close()
    
    
    # 5. Stacked Bar Chart: Test Preparation Course and Performance
    prep_course_scores = df.groupby("test preparation course")[["math score", "reading score", "writing score"]].mean()
    prep_course_scores.plot(kind="bar", stacked=True, figsize=(10, 6), colormap="coolwarm")
    plt.xlabel("Test Preparation Course")
    plt.ylabel("Average Scores")
    plt.title("Impact of Test Preparation Course on Scores (Stacked Bar Chart)")
    plt.legend(title="Subjects")
    plt.savefig(os.path.join(results_dir, "stacked_bar_test_prep.png"))  
    plt.close()

    
    # 6. Box Plot: Score Distributions by Ethnic Group
    plt.figure(figsize=(12, 6))
    sns.boxplot(x="race/ethnicity", y="average_score", data=df, palette="Set2")
    plt.title("Score Distribution by Ethnic Group (Box Plot)")
    plt.savefig(os.path.join(results_dir, "boxplot_ethnicity_scores.png"))  
    plt.close()

  

