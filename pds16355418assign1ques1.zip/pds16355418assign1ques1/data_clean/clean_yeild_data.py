import pandas as pd
import os

# Define file paths
input_file = r"C:/Documents/MyProject/data_raw/frailty_data.csv"
output_dir = r"C:/Documents/MyProject/data_clean"
output_file = os.path.join(output_dir, "cleaned_frailty_data.csv")

# Load data
df = pd.read_csv(input_file)

# Fill missing values with column average
df.fillna(df.mean(numeric_only=True), inplace=True)

# Convert 'Frailty' (N/Y) to binary (0/1)
df["Frailty"] = df["Frailty"].map({"N": 0, "Y": 1})

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Save cleaned data
df.to_csv(output_file, index=False)

print(f"Cleaned data saved to: {output_file}")

