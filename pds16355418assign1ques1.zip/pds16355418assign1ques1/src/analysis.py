import pandas as pd
from scipy.stats import ttest_ind


df = pd.read_csv(r"C:/Documents/MyProject/data_clean/cleaned_frailty_data.csv")


t_stat, p_value = ttest_ind(df[df["Frailty"] == 0]["Grip strength"], df[df["Frailty"] == 1]["Grip strength"])


with open(r"../results/test_results.txt", "w") as f:
    f.write(f"T-test Results:\nT-statistic: {t_stat}\nP-value: {p_value}")

print("Analysis complete. Results saved in test_results.txt")

